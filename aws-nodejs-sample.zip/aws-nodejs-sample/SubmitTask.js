/**
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 * with the License. A copy of the License is located at
 *
 * http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
 * OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

var util = require('util');
var AWS = require('aws-sdk');

/**
 * Before connecting to MTurk, set up your AWS account and IAM settings as described here:
 * https://blog.mturk.com/how-to-use-iam-to-control-api-access-to-your-mturk-account-76fe2c2e66e2
 *
 * Follow AWS best practices for setting credentials from here:
 * http://docs.aws.amazon.com/sdk-for-javascript/v2/developer-guide/setting-credentials-node.html
 */
AWS.config.loadFromPath('./config.json');

fs = require('fs');

/* read data */
var content = fs.readFileSync("1.tsv", "utf8");
d = content.split("\n");

c = [];
s1 = [];
s2 = [];
s3 = [];
s4 = [];
s5 = [];

for(var i = 0; i < d.length; i++){
    w = d[i].split("\t");
    c.push(w[0]);
    s1.push(w[1]);
    s2.push(w[2]);
    s3.push(w[3]);
    s4.push(w[4]);
    s5.push(w[5]);
}


//console.log(p5.length);


/**
 * Use the Amazon Mechanical Turk Sandbox to publish test Human Intelligence Tasks (HITs) without paying any
 * money. Sign up for a Sandbox account at https://requestersandbox.mturk.com/ with the same credentials as
 * your main MTurk account.
 */

var endpoint = 'https://mturk-requester-sandbox.us-east-1.amazonaws.com';
// Uncomment this line to use in production
// var endpoint = 'https://mturk-requester.us-east-1.amazonaws.com';

// Connect to sandbox
var mturk = new AWS.MTurk({ endpoint: endpoint });

// Test your ability to connect to MTurk by checking your account balance
mturk.getAccountBalance(function (err, data) {
    if (err) {
        console.log(err.message);
    } else {
        // Sandbox balance check will always return $10,000
        console.log('I have ' + data.AvailableBalance + ' in my account.');
    }
})

/* 
Publish a new HIT to the Sandbox marketplace start by reading in the HTML markup specifying your task from a seperate file (my_question.xml). To learn more about the HTML question type, see here: http://docs.aws.amazon.com/AWSMechTurk/latest/AWSMturkAPI/ApiReference_HTMLQuestionArticle.html
*/ 
// var ivc_url = "https://ivc.ischool.utexas.edu/VizWiz/data/Images/";
//var imageList = ["camera01.jpg", "camera02.jpg", "camera03.jpg"]


function doRecursionSentence(i) {
    if (i >= c.length) {
        return; // reached end, this is the reverse of "i < images.length"
    }
    var contents = c[i];
    // var image_url = ivc_url + image_name;
    console.log(contents);

    var sen1 = s1[i];
    var sen2 = s2[i];
    var sen3 = s3[i];
    var sen4 = s4[i];
    var sen5 = s5[i];

    const myQuestion =`<?xml version="1.0" encoding="UTF-8"?>
    <ExternalQuestion xmlns="http://mechanicalturk.amazonaws.com/AWSMechanicalTurkDataSchemas/2006-07-14/ExternalQuestion.xsd">
        <ExternalURL>https://nlpvagueness.z21.web.core.windows.net/?content=${contents}&amp;s1=${sen1}&amp;s2=${sen2}&amp;s3=${sen3}&amp;s4=${sen4}&amp;s5=${sen5}</ExternalURL>
        <FrameHeight>0</FrameHeight>
    </ExternalQuestion>`

    // Construct the HIT object below
    var myHIT = {
        Title: 'Mark important words in image captions',
        Description: ' NOT for those who have taken the same previous task. The images are the same. This task will help to improve the understanding of image contents. Highlight the words/phrases you think are important in given image captions.',
        MaxAssignments: 1,
        LifetimeInSeconds: 300,
        AssignmentDurationInSeconds: 180,
        Reward: '0.03',
        Question: myQuestion,

        // Add a qualification requirement that the Worker must be either in Canada or the US 
        QualificationRequirements: [
            {
                QualificationTypeId: '00000000000000000071',
                Comparator: 'In',
                LocaleValues: [
                    { Country: 'US' },
                    { Country: 'CA' },
                ],
            },
        ],
    };


    // Publish the object created above
    mturk.createHIT(myHIT, function (err, data) {
        if (err) {
            console.log(err.message);
        } else {
            console.log(data);
            // Save the HITId printed by data.HIT.HITId and use it in the RetrieveAndApproveResults.js code sample
            console.log('HIT has been successfully published here: https://workersandbox.mturk.com/mturk/preview?groupId=' + data.HIT.HITTypeId + ' with this HITId: ' + data.HIT.HITId);
            fs.appendFileSync("hits.txt", data.HIT.HITId + "\n");
        }
    });

    // do stuff with image
    setTimeout(function() {
        doRecursionSentence(i + 1);
    }, 200);
}
doRecursionSentence(0);


// for (var i in pic){
    
//         var image_name = pic[i];
//         var image_url = ivc_url + image_name;
//         console.log(image_url);

//         var caption1 = p1[i];
//         var caption2 = p2[i];
//         var caption3 = p3[i];
//         var caption4 = p4[i];
//         var caption5 = p5[i];

//         const myQuestion =`<?xml version="1.0" encoding="UTF-8"?>
//         <ExternalQuestion xmlns="http://mechanicalturk.amazonaws.com/AWSMechanicalTurkDataSchemas/2006-07-14/ExternalQuestion.xsd">
//             <ExternalURL>https://ccvimagecaption.z21.web.core.windows.net?image=${image_url}&amp;cap1=${caption1}&amp;cap2=${caption2}&amp;cap3=${caption3}&amp;cap4=${caption4}&amp;cap5=${caption5}</ExternalURL>
//             <FrameHeight>0</FrameHeight>
//         </ExternalQuestion>`


//         // Construct the HIT object below
//         var myHIT = {
//             Title: 'This is a camera annotation question',
//             Description: 'We need to segment camera from the image',
//             MaxAssignments: 1,
//             LifetimeInSeconds: 200,
//             AssignmentDurationInSeconds: 60,
//             Reward: '0.05',
//             Question: myQuestion,


//             // Add a qualification requirement that the Worker must be either in Canada or the US 
//             QualificationRequirements: [
//                 {
//                     QualificationTypeId: '00000000000000000071',
//                     Comparator: 'In',
//                     LocaleValues: [
//                         { Country: 'US' },
//                         { Country: 'CA' },
//                         { Country: 'TW' },
//                     ],
//                 },
//             ],
//         };


//         // Publish the object created above
//         mturk.createHIT(myHIT, function (err, data) {
//             if (err) {
//                 console.log(err.message);
//             } else {
//                 console.log(data);
//                 // Save the HITId printed by data.HIT.HITId and use it in the RetrieveAndApproveResults.js code sample
//                 console.log('HIT has been successfully published here: https://workersandbox.mturk.com/mturk/preview?groupId=' + data.HIT.HITTypeId + ' with this HITId: ' + data.HIT.HITId);
//                 fs.appendFileSync("hits.txt", data.HIT.HITId + "\n");
//             }
//         });
    
// }
