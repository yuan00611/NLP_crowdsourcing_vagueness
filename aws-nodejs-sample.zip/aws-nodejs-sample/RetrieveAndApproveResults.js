/**
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 * with the License. A copy of the License is located at
 *
 * http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
 * OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

var util = require('util');
var AWS = require('aws-sdk');
var fs = require('fs');
var parseString = require('xml2js').parseString;

/**
 * Before connecting to MTurk, set up your AWS account and IAM settings as described here:
 * https://blog.mturk.com/how-to-use-iam-to-control-api-access-to-your-mturk-account-76fe2c2e66e2
 *
 * Follow AWS best practices for setting credentials from here:
 * http://docs.aws.amazon.com/sdk-for-javascript/v2/developer-guide/setting-credentials-node.html
 */
AWS.config.loadFromPath('./config.json');

/**
 * Use the Amazon Mechanical Turk Sandbox to publish test Human Intelligence Tasks (HITs) without paying any
 * money. Sign up for a Sandbox account at https://requestersandbox.mturk.com/ with the same credentials as
 * your main MTurk account.
 */

// Add in the HITId below. See SubmitTask.js for generating a HIT
//var myHITId = '3RSBJ6YZEDQ3MNQIKY1HR5WI62SFO5';

var endpoint = 'https://mturk-requester-sandbox.us-east-1.amazonaws.com';
// Uncomment this line to use in production
// var endpoint = 'https://mturk-requester.us-east-1.amazonaws.com';

// Connect to sandbox
var mturk = new AWS.MTurk({ endpoint: endpoint });

var hits = fs.readFileSync("hits.txt", "utf8").split("\n");

/**
 * To keep this example simple, we are assuming that there are fewer
 * than 10 results and there is no need to iterate through pages of results
 */





hits.forEach(function(myHITId) {
    if (!myHITId) return;

    /**
     * To keep this example simple, we are assuming that there are fewer
     * than 10 results and there is no need to iterate through pages of results
     */

    mturk.listAssignmentsForHIT({ HITId: myHITId }, function(
        err,
        assignmentsForHIT
    ) {
        if (err) {
            console.log(err.message);
        } else {
            console.log(
                "Completed Assignments found: " + assignmentsForHIT.NumResults
            );
            for (var i = 0; i < assignmentsForHIT.NumResults; i++) {
                // var textArray = assignmentsForHIT.Assignments[i].Answer.match(
                //     /<FreeText>([\s\S]*?)<\/FreeText>/
                // )[1];


                //console.log(assignmentsForHIT.Assignments[i].Answer);

                parseString(assignmentsForHIT.Assignments[i].Answer, function(err, result)
                { 
                    console.log(result) 
                    //console.log(util.inspect(result, false, null));

                    // var imagePath = result["QuestionFormAnswers"]["Answer"][0]["QuestionIdentifier"];
                    // var textArray = result["QuestionFormAnswers"]["Answer"][0]["FreeText"];

                    // var e1 = result["QuestionFormAnswers"]["Answer"][1]["FreeText"];
                    // var e2 = result["QuestionFormAnswers"]["Answer"][2]["FreeText"];
                    // var e3 = result["QuestionFormAnswers"]["Answer"][3]["FreeText"];
                    // var e4 = result["QuestionFormAnswers"]["Answer"][4]["FreeText"];
                    // var e5 = result["QuestionFormAnswers"]["Answer"][5]["FreeText"];
                    
                    // var best = result["QuestionFormAnswers"]["Answer"][6]["FreeText"];
                    // var reason = result["QuestionFormAnswers"]["Answer"][7]["FreeText"];
                    // if (result["QuestionFormAnswers"]["Answer"][8] != null) {
                    //     var suggest = result["QuestionFormAnswers"]["Answer"][8]["FreeText"];
                    // }
                    

                    //console.log(imagePath, textArray, e1, e2, e3, e4, e5, best, reason, suggest);
                    // console.log(imagePath, textArray, e1, e2, e3, e4, best, reason, suggest);

                    // fs.appendFileSync(
                    // "responses5.tsv",
                    // `${myHITId}\t${assignmentsForHIT.Assignments[i].WorkerId}\t${imagePath}\t${textArray}\t${e1}\t${e2}\t${e3}\t${e4}\t${e5}\t${best}\t${reason}\t${suggest}\n`
                    // //`${myHITId}\t${assignmentsForHIT.Assignments[i].WorkerId}\t${imagePath}\t${textArray}\t${e1}\t${e2}\t${e3}\t${e4}\t${best}\t${reason}\t${suggest}\n`
                    // );

                });


                // console.log(
                //     "Answer from Worker with ID - " +
                //         assignmentsForHIT.Assignments[i].WorkerId +
                //         ": ",
                //     imagePath,
                //     textArray,
                //     e1,
                //     e2,
                //     e3,
                //     e4,
                //     e5,
                //     best,
                //     reason,
                // );

                // fs.appendFileSync(
                //     "responses.tsv",
                //     `${myHITId}\t${assignmentsForHIT.Assignments[i].WorkerId}\t${imagePath}\t${textArray}\t${e1}\t${e2}\t${e3}\t${e4}\t${e5}\t${best}\t${reason}\n`
                // );

                // Approve the work so the Worker is paid with and optional feedback message
                // mturk.approveAssignment(
                //  {
                //      AssignmentId: assignmentsForHIT.Assignments[i].AssignmentId,
                //      RequesterFeedback: "Thanks for the great work!"
                //  },
                //  function(err) {
                //      if (err) {
                //          console.log(err, err.stack);
                //      }
                //  }
                // );

                // mturk.rejectAssignment(
                // {
                //     AssignmentId:,
                //     RequesterFeedback: "poor quality ",
                // },
                // function(err) {
                //     if (err) {
                //         console.log(err, err.stack);
                //      }
                //  }
                // );
            }
        }
    });
});
